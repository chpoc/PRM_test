export function hello() {
    return 'Hello World!';
}

export default hello;